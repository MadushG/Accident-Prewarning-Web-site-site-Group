<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Current Location on OSM with Routing</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.css" />
    <style>
        #map {
            height: 600px; /* Set the height of the map */
            width: 100%;   /* Set the width of the map */
        }
        .destination-marker {
            color: red; /* Color for the destination marker */
        }
        .poi-marker {
            color: blue; /* Color for the POI markers */
        }
        .start-marker, .end-marker {
            background-color: yellow;
            border: 2px solid red;
            border-radius: 50%;
            width: 12px;
            height: 12px;
        }
        #poiTable {
            margin-top: 20px;
            width: 100%;
            border-collapse: collapse; /* Collapse borders */
        }
        #poiTable th, #poiTable td {
            border: 1px solid #ddd; /* Table border */
            padding: 8px; /* Cell padding */
            text-align: left; /* Left align text */
        }
        #poiTable th {
            background-color: #f2f2f2; /* Header background color */
        }
    </style>
</head>
<body>
    <h1>Location</h1>
    <div id="map"></div>
    <button id="getRouteButton" style="margin-top: 10px;">Get Route</button>
    <div style="margin-top: 10px;">
        <input type="text" id="destinationInput" placeholder="Enter destination name" />
        <button id="setDestinationButton">Set Destination</button>
    </div>
    
    <h2>Emergency Places</h2>
    <table id="poiTable">
        <thead>
            <tr>
                <th>Place Name</th>
                <th>Type</th>
                <th>Distance from Start (m)</th>
            </tr>
        </thead>
        <tbody id="poiTableBody"></tbody> <!-- Body for displaying nearby places -->
    </table>

    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.js"></script>
    <script>
        // Initialize the map
        var map = L.map('map').setView([0, 0], 2); // Default view to show the world

        // Add OpenStreetMap tiles
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '© OpenStreetMap'
        }).addTo(map);

        var routingControl; // Variable to hold the routing control
        var userMarker; // Marker for the user's location
        var destinationMarker; // Marker for the destination location
        var selectedDestination; // To store the selected destination

        // Custom start and end markers
        var startMarkerIcon = L.divIcon({className: 'start-marker'});
        var endMarkerIcon = L.divIcon({className: 'end-marker'});

        // Get the user's current location
        function onLocationFound(e) {
            var radius = e.accuracy / 2;

            // Remove previous user marker if it exists
            if (userMarker) {
                map.removeLayer(userMarker);
            }

            // Add a marker for the user's location
            userMarker = L.marker(e.latlng, {icon: startMarkerIcon}).addTo(map)
                .bindPopup("You are here!").openPopup();

            // Circle around the location
            L.circle(e.latlng, radius).addTo(map);
            map.setView(e.latlng, 13); // Zoom into the user's location
        }

        function onLocationError(e) {
            alert(e.message);
        }

        // Get the current location
        map.locate({setView: true, maxZoom: 13});

        // Event listeners for location found and error
        map.on('locationfound', onLocationFound);
        map.on('locationerror', onLocationError);

        // Function to plot a route to a selected destination
        function plotRoute(destination) {
            if (routingControl) {
                map.removeControl(routingControl); // Remove previous route if it exists
            }

            // Create a new routing control with start and end waypoints
            routingControl = L.Routing.control({
                waypoints: [
                    L.latLng(userMarker.getLatLng().lat, userMarker.getLatLng().lng), // User's location (Start)
                    L.latLng(destination.lat, destination.lng) // Destination (End)
                ],
                createMarker: function(i, wp, nWps) {
                    if (i === 0) {
                        return L.marker(wp.latLng, {icon: startMarkerIcon}).bindPopup("Start: Your Location");
                    } else if (i === nWps - 1) {
                        return L.marker(wp.latLng, {icon: endMarkerIcon}).bindPopup("End: Destination");
                    }
                },
                routeWhileDragging: true
            }).addTo(map);

            // After plotting the route, load nearby places
            loadNearbyPlaces(destination);
        }

        // Function to load nearby places (hospitals, garages, petrol stations)
        function loadNearbyPlaces(destination) {
            // Clear previous POI markers if they exist
            if (map._poiMarkers) {
                map._poiMarkers.forEach(marker => {
                    map.removeLayer(marker);
                });
            }

            // Clear the POI table
            var poiTableBody = document.getElementById('poiTableBody');
            poiTableBody.innerHTML = ''; // Clear previous table rows

            // Prepare Overpass API query
            var query = `
                [out:json];
                (
                    node["amenity"="hospital"](around:2000, ${destination.lat}, ${destination.lng});
                    node["amenity"="garage"](around:2000, ${destination.lat}, ${destination.lng});
                    node["amenity"="fuel"](around:2000, ${destination.lat}, ${destination.lng});
                );
                out body;
            `;

            // Fetch POIs from Overpass API
            fetch(`https://overpass-api.de/api/interpreter?data=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    // Store POI markers
                    map._poiMarkers = [];
                    data.elements.forEach(element => {
                        if (element.lat && element.lon) {
                            var poiMarker = L.marker([element.lat, element.lon], {
                                icon: L.divIcon({className: 'poi-marker'})
                            }).addTo(map)
                            .bindPopup(element.tags.name || "Unnamed");

                            map._poiMarkers.push(poiMarker); // Store in an array for later removal

                            // Calculate distance from the start point
                            var distance = map.latLngToLayerPoint(userMarker.getLatLng()).distanceTo(
                                map.latLngToLayerPoint([element.lat, element.lon])
                            );

                            // Add the place name to the table
                            var row = poiTableBody.insertRow();
                            row.insertCell(0).textContent = element.tags.name || "Unnamed Place"; // Place name
                            row.insertCell(1).textContent = element.tags.amenity || "Unknown Type"; // Type
                            row.insertCell(2).textContent = Math.round(distance) + " m"; // Distance
                        }
                    });
                })
                .catch(error => {
                    console.error("Error fetching POIs:", error);
                });
        }

        // Function to get coordinates from a location name
        function getCoordinatesFromName(locationName) {
            return fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(locationName)}&format=json&limit=1`)
                .then(response => response.json())
                .then(data => {
                    if (data.length > 0) {
                        return { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) };
                    } else {
                        throw new Error("Location not found");
                    }
                });
        }

        // Event listener for setting destination from input
        document.getElementById('setDestinationButton').onclick = function() {
            var input = document.getElementById('destinationInput').value;

            if (input) {
                // Get coordinates from location name
                getCoordinatesFromName(input)
                    .then(coordinates => {
                        selectedDestination = coordinates;

                        // Remove previous destination marker if it exists
                        if (destinationMarker) {
                            map.removeLayer(destinationMarker);
                        }

                        // Add a marker for the destination
                        destinationMarker = L.marker([coordinates.lat, coordinates.lng], {
                            icon: endMarkerIcon
                        }).addTo(map)
                        .bindPopup("Destination: " + input).openPopup();

                        // Plot the route to the new destination
                        plotRoute(selectedDestination);
                    })
                    .catch(error => {
                        alert(error.message);
                    });
            } else {
                alert("Please enter a destination.");
            }
        };

        // Event listener for getting the route
        document.getElementById('getRouteButton').onclick = function() {
            if (selectedDestination) {
                plotRoute(selectedDestination);
            } else {
                alert("Please set a destination first.");
            }
        };
    </script>
</body>
</html>
